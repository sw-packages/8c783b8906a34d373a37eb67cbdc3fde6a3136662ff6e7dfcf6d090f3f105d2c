#ifndef TELEGRAM_TYPES_REPLY_MARKUP_H_INCLUDED
#define TELEGRAM_TYPES_REPLY_MARKUP_H_INCLUDED

#include "force_reply.h"
#include "inline_keyboard_markup.h"
#include "reply_keyboard_remove.h"
#include "reply_keyboard_markup.h"

#endif // TELEGRAM_TYPES_REPLY_MARKUP_H_INCLUDED
